/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.hama.bsp.message.compress;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.compress.BZip2Codec;
import org.apache.hadoop.io.compress.CompressionInputStream;
import org.apache.hadoop.io.compress.CompressionOutputStream;
import org.apache.hama.bsp.BSPMessageBundle;

public class Bzip2Compressor<M extends Writable> extends
    BSPMessageCompressor<M> {

  private final BZip2Codec codec = new BZip2Codec();

  @Override
  public BSPCompressedBundle compressBundle(BSPMessageBundle<M> bundle) {
    BSPCompressedBundle compMsgBundle = null;
    ByteArrayOutputStream bos = null;
    CompressionOutputStream sos = null;
    DataOutputStream dos = null;

    try {
      bos = new ByteArrayOutputStream();
      sos = codec.createOutputStream(bos);
      dos = new DataOutputStream(sos);

      bundle.write(dos);
      dos.close(); // Flush the stream as no more data will be sent.

      byte[] data = bos.toByteArray();
      compMsgBundle = new BSPCompressedBundle(data);

    } catch (IOException ioe) {
      LOG.error("Unable to compress", ioe);
    } finally {
      try {
        sos.close();
        bos.close();
      } catch (IOException e) {
        LOG.warn("Failed to close compression streams.", e);
      }
    }
    return compMsgBundle;
  }

  /**
   * Decompresses a BSPCompressedBundle and returns the corresponding
   * BSPMessageBundle.
   * 
   * @param compMsgBundle
   * @return
   */
  @Override
  public BSPMessageBundle<M> decompressBundle(BSPCompressedBundle compMsgBundle) {
    ByteArrayInputStream bis = null;
    CompressionInputStream sis = null;
    DataInputStream dis = null;
    BSPMessageBundle<M> bundle = new BSPMessageBundle<M>();

    try {
      byte[] data = compMsgBundle.getData();
      bis = new ByteArrayInputStream(data);
      sis = codec.createInputStream(bis);
      dis = new DataInputStream(sis);

      bundle.readFields(dis);

    } catch (IOException ioe) {
      LOG.error("Unable to decompress.", ioe);
    } finally {
      try {
        dis.close();
        sis.close();
        bis.close();
      } catch (IOException e) {
        LOG.warn("Failed to close decompression streams.", e);
      }
    }

    return bundle;
  }

}
